# 🎶 Spotify Clone

A basic Spotify UI Clone built using HTML, CSS, and JavaScript.

Learning project created while practicing frontend skills.
