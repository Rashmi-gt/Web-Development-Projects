# 🎮 Simon Says Game

A fun memory game built using HTML, CSS, and JavaScript.

Player needs to follow and repeat the sequence shown by the computer.
