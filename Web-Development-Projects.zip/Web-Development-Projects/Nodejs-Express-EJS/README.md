# 🌐 Node.js + Express + EJS Practice

Beginner backend practice projects using Node.js, Express.js, and EJS.

Includes simple servers, templates, and REST APIs.
