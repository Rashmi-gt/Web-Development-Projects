# 🌐 Family Business Webpage

A simple static website designed for my family business using HTML, CSS, and JavaScript.

Beginner-level project created during my initial web development learning phase.
